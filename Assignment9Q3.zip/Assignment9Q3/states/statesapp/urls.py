from django.urls import path,include
from statesapp import views
from .views import(
    StateListView,
    StateDetailView,
    StateCreateView,
    StateUpdateView,
    StateDeleteView
)

urlpatterns = [
    path('index',views.index),
    path('',StateListView.as_view(),name='state-list'),
    path('detail/<int:pk>/', StateDetailView.as_view(), name='state-detail'),
    path('create/', StateCreateView.as_view(), name='state-create'),
    path('update/<int:pk>/', StateUpdateView.as_view(), name='state-update'),
    path('delete/<int:pk>/', StateDeleteView.as_view(), name='state-delete'),
    
]