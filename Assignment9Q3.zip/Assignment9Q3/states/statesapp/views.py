from django.shortcuts import render,HttpResponse,redirect
from django.views.generic import ListView,DetailView,CreateView,UpdateView,DeleteView
from django.urls import reverse_lazy
from .models import States


# Create your views here.
def index(request):
    return HttpResponse("This is index page")

class StateListView(ListView):
    model = States
    template_name= 'states_list.html'
    context_object_name = 'states'
    
class StateDetailView(DeleteView):
    model = States
    template_name ='states_details.html'
    context_object_name ='state'
    
class StateCreateView(CreateView):
    model=States
    template_name ='states_form.html'
    fields =['name','population','language','capital']
    success_url = reverse_lazy('state-list')
    
class StateUpdateView(UpdateView):
    model = States
    template_name = 'states_form.html'
    fields = ['name','population','language','capital']
    success_url = reverse_lazy('state-list')
    
class StateDeleteView(DeleteView):
    model = States
    template_name = 'states_confirm_delete.html'
    success_url = reverse_lazy('state-list')









